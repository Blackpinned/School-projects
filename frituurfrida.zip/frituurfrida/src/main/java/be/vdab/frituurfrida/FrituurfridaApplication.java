package be.vdab.frituurfrida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrituurfridaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrituurfridaApplication.class, args);
	}
}
